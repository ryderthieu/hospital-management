export interface PasswordChangeFormData {
    currentPassword: string;
    newPassword: string;
    confirmPassword: string;
  }