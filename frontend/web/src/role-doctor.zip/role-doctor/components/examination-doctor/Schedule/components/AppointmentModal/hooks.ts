// This file would contain any AppointmentModal-specific hooks
// Currently, no custom hooks are needed for AppointmentModal
