// This file would contain any WeekView-specific services
// Currently, all services are in the shared services file
