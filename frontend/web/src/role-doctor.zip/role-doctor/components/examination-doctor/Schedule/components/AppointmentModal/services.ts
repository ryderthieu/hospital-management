// This file would contain any AppointmentModal-specific services
// Currently, all services are in the shared services file
