// This file would contain any Schedule-specific types
// Currently, all types are in the shared types file
