// This file would contain any MonthView-specific services
// Currently, all services are in the shared services file
