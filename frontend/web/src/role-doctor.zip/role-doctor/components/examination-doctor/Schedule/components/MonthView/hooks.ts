// This file would contain any MonthView-specific hooks
// Currently, no custom hooks are needed for MonthView
