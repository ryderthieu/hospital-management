import React from 'react'

const Patients: React.FC = () => {
  return (
    <div>Patient</div>
  )
}

export default Patients