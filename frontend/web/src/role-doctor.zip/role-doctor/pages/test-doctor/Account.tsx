import React from 'react'

const Account: React.FC = () => {
  return (
    <div>Account</div>
  )
}

export default Account