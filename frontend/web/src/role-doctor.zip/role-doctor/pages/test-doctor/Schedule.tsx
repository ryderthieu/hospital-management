import React from 'react'

const Schedule: React.FC = () => {
  return (
    <div>Schedule</div>
  )
}

export default Schedule