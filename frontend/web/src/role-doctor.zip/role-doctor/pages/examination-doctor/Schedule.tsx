import { ScheduleComponent } from "../../components/examination-doctor/Schedule/components/Schedule/index"

const Schedule = () => {
  return (
    <div className="container mx-auto p-4">
      <ScheduleComponent />
    </div>
  )
}

export default Schedule
